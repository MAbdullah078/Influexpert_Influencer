import { Injectable } from '@angular/core';

@Injectable()
export class Config {
    // public static api: String = 'https://influexpapi.herokuapp.com';
    // public static api: String = 'http://ns520442.ip-158-69-23.net:4433';
    // public static api: String = 'http://localhost:8000';
    // public static api: String = 'http://192.168.29.162:9000';
    // public static api: String = 'http://127.0.0.1:8000';
  // public static api: String = 'http://192.168.29.166:8000';
  public static api: String = 'https://apis.influexpai.com';
  public  static  Imageurlupload = 'https://storage.influexpai.com/test_hamza.php';

  
  // public static api: String = 'https://apis.influexpai.com';

  // public static api: String = 'https://apis.influexpai.com';
  // public static api: String = 'https://apis.influexpai.com';
  // public static api: String = 'https://apis.influexpai.com';
  // public static api: String = 'https://apis.influexpai.com';
  // public static api: String = 'https://apis.influexpai.com';


  // public static api: String = 'https://192www.influexp.com';
    // public static api: String = 'http://www.influexpai.com';
}

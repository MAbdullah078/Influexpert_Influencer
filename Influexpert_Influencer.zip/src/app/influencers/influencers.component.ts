import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-influencers',
  templateUrl: './influencers.component.html',
  styleUrls: ['./influencers.component.scss']
})
export class InfluencersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scroll(0,0);

  }

}

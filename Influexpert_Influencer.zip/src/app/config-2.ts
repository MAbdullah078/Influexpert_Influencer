import { Injectable } from '@angular/core';

@Injectable()
export class Config2 {
    public static api: String = '';
}
